package com.klh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCrudJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductCrudJpaApplication.class, args);
	}

}
