import axios from "axios";

const API = "http://localhost:8080/api/products";

export const getProducts = () => axios.get(API);
export const addProduct = (data: any) => axios.post(API, data);
export const deleteProduct = (id: number) =>
  axios.delete(`${API}/${id}`);