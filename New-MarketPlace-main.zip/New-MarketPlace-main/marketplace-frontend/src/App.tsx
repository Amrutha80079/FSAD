import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

import Products from "./pages/Products";
import Admin from "./pages/Admin";
import Login from "./pages/Login";
import AdminLogin from "./pages/AdminLogin";

function App() {
  const [loggedIn] = useState(localStorage.getItem("login") === "true");

  // 🧑 USER LOGOUT
  const logout = () => {
    localStorage.removeItem("login");
    window.location.href = "/";
  };

  if (!loggedIn) {
    return <Login onLogin={() => {}} />;
  }

  return (
    <Router>
      <nav className="navbar navbar-dark bg-dark px-4">
        <h3 className="text-white">🛒 Marketplace</h3>

        <div>
          <Link to="/" className="btn btn-light me-2">
            Products
          </Link>

          <Link to="/admin" className="btn btn-warning me-2">
            Admin
          </Link>

          {/* USER LOGOUT */}
          <button className="btn btn-danger" onClick={logout}>
            Logout
          </button>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Products />} />

        {/* ADMIN ROUTE PROTECTION */}
        <Route
          path="/admin"
          element={
            localStorage.getItem("admin") === "true"
              ? <Admin />
              : <AdminLogin />
          }
        />
      </Routes>
    </Router>
  );
}

export default App;