import React, { useState } from "react";
import axios from "axios";

type Props = {
  onLogin: () => void;
};

export default function Login({ onLogin }: Props) {
  const [isRegister, setIsRegister] = useState(false);

  const [form, setForm] = useState<any>({
    name: "",
    username: "",
    email: "",
    password: "",
    confirmPassword: "",
    address: "",
    mobile: "",
  });

  // 🔐 LOGIN FUNCTION
  const login = async () => {
    if (!form.username || !form.password) {
      alert("Please enter username and password");
      return;
    }

    try {
      const res = await axios.post("http://localhost:8080/api/auth/login", {
        username: form.username,
        password: form.password,
      });

      if (res.data === "Login successful") {
        localStorage.setItem("login", "true");
        window.location.href = "/";
      } else {
        alert("Invalid username or password ❌");
      }
    } catch (err) {
      alert("Login failed ❌");
    }
  };

  // 📝 REGISTER FUNCTION
  const register = async () => {
    if (
      !form.name ||
      !form.username ||
      !form.email ||
      !form.password ||
      !form.confirmPassword ||
      !form.address ||
      !form.mobile
    ) {
      alert("Please fill all fields ⚠️");
      return;
    }

    if (form.password !== form.confirmPassword) {
      alert("Passwords do not match ❌");
      return;
    }

    try {
      await axios.post("http://localhost:8080/api/auth/register", form);

      alert("Registered successfully ✅");
      setIsRegister(false);
    } catch (err) {
      alert("Registration failed ❌");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>

        <h2 style={styles.title}>
          {isRegister ? "Create Account 📝" : "Welcome Back 👋"}
        </h2>

        {isRegister && (
          <>
            <input style={styles.input} placeholder="Name"
              onChange={(e) => setForm({ ...form, name: e.target.value })} />

            <input style={styles.input} placeholder="Email"
              onChange={(e) => setForm({ ...form, email: e.target.value })} />
          </>
        )}

        <input style={styles.input} placeholder="Username"
          onChange={(e) => setForm({ ...form, username: e.target.value })} />

        <input style={styles.input} type="password" placeholder="Password"
          onChange={(e) => setForm({ ...form, password: e.target.value })} />

        {isRegister && (
          <>
            <input style={styles.input} type="password" placeholder="Confirm Password"
              onChange={(e) =>
                setForm({ ...form, confirmPassword: e.target.value })
              } />

            <input style={styles.input} placeholder="Address (only for delivery purpose)"
              onChange={(e) =>
                setForm({ ...form, address: e.target.value })
              } />

            <input style={styles.input} placeholder="Mobile Number"
              onChange={(e) =>
                setForm({ ...form, mobile: e.target.value })
              } />
          </>
        )}

        {!isRegister ? (
          <>
            <button style={styles.button} onClick={login}>Login</button>

            <p style={styles.text}>
              New user?{" "}
              <span style={styles.link} onClick={() => setIsRegister(true)}>
                Register here
              </span>
            </p>
          </>
        ) : (
          <>
            <button style={styles.button} onClick={register}>Register</button>

            <p style={styles.text}>
              Already have account?{" "}
              <span style={styles.link} onClick={() => setIsRegister(false)}>
                Login
              </span>
            </p>
          </>
        )}

      </div>
    </div>
  );
}

const styles: any = {
  container: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(135deg, #e0f7ff, #cceeff, #b3e5fc)",
    fontFamily: "Segoe UI, sans-serif",
  },

  card: {
    width: "420px",
    maxHeight: "90vh",
    overflowY: "auto",
    padding: "35px",
    borderRadius: "20px",
    background: "rgba(255,255,255,0.75)",
    backdropFilter: "blur(12px)",
    boxShadow: "0 10px 40px rgba(0,150,255,0.25)",
    border: "1px solid rgba(255,255,255,0.6)",
    textAlign: "center",
    animation: "fadeSlide 0.6s ease",
  },

  title: {
    color: "#0077b6",
    marginBottom: "20px",
  },

  input: {
    width: "100%",
    padding: "13px",
    margin: "8px 0",
    borderRadius: "12px",
    border: "1px solid #d0ecff",
    outline: "none",
    fontSize: "14px",
    background: "rgba(255,255,255,0.95)",
    transition: "0.3s",
  },

  button: {
    width: "100%",
    padding: "13px",
    marginTop: "15px",
    borderRadius: "12px",
    border: "none",
    background: "linear-gradient(135deg, #00c6ff, #0072ff)",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "0.3s",
  },

  text: {
    marginTop: "15px",
    color: "#555",
  },

  link: {
    color: "#0072ff",
    fontWeight: "bold",
    cursor: "pointer",
  },
};

// Inject animation globally
const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
@keyframes fadeSlide {
  from {
    opacity: 0;
    transform: translateY(30px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}
button:hover {
  transform: translateY(-2px) scale(1.03);
  box-shadow: 0 8px 20px rgba(0,140,255,0.4);
}
input:focus {
  border-color: #00b4ff;
  box-shadow: 0 0 8px rgba(0,180,255,0.4);
  transform: scale(1.02);
}
span:hover {
  text-decoration: underline;
  color: #0056cc;
}
`;
document.head.appendChild(styleSheet);