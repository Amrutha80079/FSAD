import React, { useState } from "react";

export default function AdminLogin() {
  const [user, setUser] = useState("");
  const [pass, setPass] = useState("");

  const login = () => {
    if (user === "admin" && pass === "admin123") {
      localStorage.setItem("admin", "true");
      window.location.href = "/admin";
    } else {
      alert("Invalid admin credentials");
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <h2 style={styles.title}>👑 Admin Login</h2>

        <input
          style={styles.input}
          placeholder="Username"
          onChange={(e) => setUser(e.target.value)}
        />

        <input
          style={styles.input}
          type="password"
          placeholder="Password"
          onChange={(e) => setPass(e.target.value)}
        />

        <button style={styles.button} onClick={login}>
          Login
        </button>
      </div>
    </div>
  );
}

const styles: any = {
  container: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(135deg, #e0f7ff, #cceeff, #b3e5fc)",
    fontFamily: "Segoe UI, sans-serif",
  },

  card: {
    width: "420px",
    padding: "35px",
    borderRadius: "20px",
    background: "rgba(255,255,255,0.75)",
    backdropFilter: "blur(12px)",
    boxShadow: "0 10px 40px rgba(0,150,255,0.25)",
    border: "1px solid rgba(255,255,255,0.6)",
    textAlign: "center",
    animation: "fadeSlide 0.6s ease",
  },

  title: {
    color: "#0077b6",
    marginBottom: "25px",
  },

  input: {
    width: "100%",
    padding: "13px",
    margin: "10px 0",
    borderRadius: "12px",
    border: "1px solid #d0ecff",
    outline: "none",
    fontSize: "14px",
    background: "rgba(255,255,255,0.95)",
    transition: "0.3s",
  },

  button: {
    width: "100%",
    padding: "13px",
    marginTop: "15px",
    borderRadius: "12px",
    border: "none",
    background: "linear-gradient(135deg, #00c6ff, #0072ff)",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "0.3s",
  },
};

// same animation + hover effects
const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
@keyframes fadeSlide {
  from {
    opacity: 0;
    transform: translateY(30px) scale(0.95);
  }
  to {
    opacity: 1;
    transform: translateY(0) scale(1);
  }
}
button:hover {
  transform: translateY(-2px) scale(1.03);
  box-shadow: 0 8px 20px rgba(0,140,255,0.4);
}
input:focus {
  border-color: #00b4ff;
  box-shadow: 0 0 8px rgba(0,180,255,0.4);
  transform: scale(1.02);
}
`;
document.head.appendChild(styleSheet);