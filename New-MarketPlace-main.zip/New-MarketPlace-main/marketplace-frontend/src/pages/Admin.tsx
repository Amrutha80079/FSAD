import React, { useEffect, useState } from "react";
import { getProducts, addProduct, deleteProduct } from "../services/api";

export default function Admin() {
  const [products, setProducts] = useState<any[]>([]);
  const [form, setForm] = useState<any>({
    name: "",
    description: "",
    price: "",
    imageUrl: "",
  });

  const logoutAdmin = () => {
    localStorage.removeItem("admin");
    window.location.href = "/";
  };

  const load = () =>
    getProducts().then((res: any) => setProducts(res.data));

  useEffect(() => {
    load();
  }, []);

  const handleAdd = async () => {
    if (!form.name || !form.description || !form.price || !form.imageUrl) {
      alert("Please fill all fields ⚠️");
      return;
    }

    await addProduct({
      name: form.name,
      description: form.description,
      price: Number(form.price),
      imageUrl: form.imageUrl,
    });

    alert("Product added ✅");

    setForm({
      name: "",
      description: "",
      price: "",
      imageUrl: "",
    });

    load();
  };

  return (
    <div style={styles.container}>

      {/* HEADER */}
      <div style={styles.header}>
        <h2 style={styles.title}>👑 Admin Panel</h2>

        {localStorage.getItem("admin") === "true" && (
          <button style={styles.logoutBtn} onClick={logoutAdmin}>
            Logout
          </button>
        )}
      </div>

      {/* ADD PRODUCT CARD */}
      <div style={styles.card}>
        <h3 style={styles.cardTitle}>Add Product</h3>

        <input style={styles.input} placeholder="Product Name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })} />

        <input style={styles.input} placeholder="Description"
          value={form.description}
          onChange={(e) => setForm({ ...form, description: e.target.value })} />

        <input style={styles.input} placeholder="Price"
          value={form.price}
          onChange={(e) => setForm({ ...form, price: e.target.value })} />

        <input style={styles.input} placeholder="Image URL"
          value={form.imageUrl}
          onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} />

        <button style={styles.addBtn} onClick={handleAdd}>
          Add Product
        </button>
      </div>

      {/* PRODUCT LIST */}
      <h3 style={styles.sectionTitle}>All Products</h3>

      <div style={styles.grid}>
        {products.map((p: any) => (
          <div key={p.id} style={styles.productCard}>

            <img src={p.imageUrl} alt="" style={styles.image} />

            <h4>{p.name}</h4>
            <p style={styles.desc}>{p.description}</p>
            <p style={styles.price}>₹{p.price}</p>

            <button
              style={styles.deleteBtn}
              onClick={() => deleteProduct(p.id).then(load)}
            >
              Delete
            </button>

          </div>
        ))}
      </div>
    </div>
  );
}

const styles: any = {
  container: {
    minHeight: "100vh",
    padding: "30px",
    background: "linear-gradient(135deg, #e0f7ff, #cceeff, #b3e5fc)",
    fontFamily: "Segoe UI, sans-serif",
  },

  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "20px",
  },

  title: {
    color: "#0077b6",
  },

  logoutBtn: {
    padding: "10px 18px",
    borderRadius: "10px",
    border: "none",
    background: "linear-gradient(135deg, #ff4d4d, #cc0000)",
    color: "#fff",
    cursor: "pointer",
    transition: "0.3s",
  },

  card: {
    padding: "25px",
    borderRadius: "20px",
    background: "rgba(255,255,255,0.75)",
    backdropFilter: "blur(12px)",
    boxShadow: "0 10px 40px rgba(0,150,255,0.25)",
    marginBottom: "30px",
    animation: "fadeSlide 0.5s ease",
  },

  cardTitle: {
    marginBottom: "15px",
    color: "#0077b6",
  },

  input: {
    width: "100%",
    padding: "12px",
    margin: "8px 0",
    borderRadius: "10px",
    border: "1px solid #d0ecff",
    outline: "none",
    transition: "0.3s",
  },

  addBtn: {
    marginTop: "10px",
    padding: "12px",
    width: "100%",
    borderRadius: "10px",
    border: "none",
    background: "linear-gradient(135deg, #00c6ff, #0072ff)",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "0.3s",
  },

  sectionTitle: {
    marginBottom: "15px",
    color: "#0077b6",
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(250px, 1fr))",
    gap: "20px",
  },

  productCard: {
    padding: "15px",
    borderRadius: "15px",
    background: "rgba(255,255,255,0.8)",
    backdropFilter: "blur(10px)",
    boxShadow: "0 5px 20px rgba(0,150,255,0.2)",
    textAlign: "center",
    transition: "0.3s",
  },

  image: {
    width: "100%",
    height: "150px",
    objectFit: "cover",
    borderRadius: "10px",
    marginBottom: "10px",
  },

  desc: {
    fontSize: "13px",
    color: "#555",
  },

  price: {
    fontWeight: "bold",
    color: "#0077b6",
  },

  deleteBtn: {
    marginTop: "10px",
    padding: "8px",
    width: "100%",
    borderRadius: "10px",
    border: "none",
    background: "linear-gradient(135deg, #ff4d4d, #cc0000)",
    color: "#fff",
    cursor: "pointer",
  },
};

// animations + hover
const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
@keyframes fadeSlide {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
button:hover {
  transform: translateY(-2px) scale(1.03);
  box-shadow: 0 8px 20px rgba(0,140,255,0.3);
}
input:focus {
  border-color: #00b4ff;
  box-shadow: 0 0 6px rgba(0,180,255,0.4);
}
.product-card:hover {
  transform: scale(1.03);
}
`;
document.head.appendChild(styleSheet);