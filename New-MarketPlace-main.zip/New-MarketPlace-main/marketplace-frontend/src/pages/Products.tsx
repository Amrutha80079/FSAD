import React, { useEffect, useState } from "react";
import { getProducts } from "../services/api";

export default function Products() {
  const [products, setProducts] = useState<any[]>([]);
  const [cart, setCart] = useState<any[]>([]);
  const [search, setSearch] = useState("");

  const loadProducts = () => {
    getProducts()
      .then((res: any) => {
        console.log("PRODUCTS:", res.data);
        setProducts(res.data);
      })
      .catch((err) => console.error(err));
  };

  useEffect(() => {
    loadProducts();
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("cart");
    if (saved) setCart(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart));
  }, [cart]);

  const addToCart = (p: any) => {
    const exist = cart.find((i) => i.id === p.id);

    if (exist) {
      setCart(
        cart.map((i) =>
          i.id === p.id ? { ...i, quantity: i.quantity + 1 } : i
        )
      );
    } else {
      setCart([...cart, { ...p, quantity: 1 }]);
    }
  };

  const remove = (id: number) =>
    setCart(cart.filter((i) => i.id !== id));

  const total = cart.reduce(
    (sum, i) => sum + i.price * i.quantity,
    0
  );

  const checkout = () => {
    alert("Order placed!");
    setCart([]);
  };

  return (
    <div style={styles.container}>

      {/* SEARCH */}
      <input
        style={styles.search}
        placeholder="🔍 Search products..."
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* PRODUCTS GRID */}
      <div style={styles.grid}>
        {products
          .filter((p: any) =>
            p.name.toLowerCase().includes(search.toLowerCase())
          )
          .map((p: any) => (
            <div style={styles.card} key={p.id}>

              <img
                src={p.imageUrl || "https://via.placeholder.com/300"}
                style={styles.image}
                alt={p.name}
              />

              <h4>{p.name}</h4>
              <p style={styles.desc}>{p.description}</p>
              <h3 style={styles.price}>₹{p.price}</h3>

              <button
                style={styles.button}
                onClick={() => addToCart(p)}
              >
                Add to Cart
              </button>
            </div>
          ))}
      </div>

      {/* CART */}
      <div style={styles.cartBox}>
        <h3>🛒 Cart</h3>

        {cart.map((i: any) => (
          <div key={i.id} style={styles.cartItem}>
            {i.name} x {i.quantity}

            <button style={styles.removeBtn} onClick={() => remove(i.id)}>
              Remove
            </button>
          </div>
        ))}

        <h3 style={styles.total}>Total: ₹{total}</h3>

        <button style={styles.checkout} onClick={checkout}>
          Checkout
        </button>
      </div>
    </div>
  );
}

const styles: any = {
  container: {
    minHeight: "100vh",
    padding: "30px",
    background: "linear-gradient(135deg, #e0f7ff, #cceeff, #b3e5fc)",
    fontFamily: "Segoe UI, sans-serif",
  },

  search: {
    width: "100%",
    padding: "14px",
    borderRadius: "12px",
    border: "1px solid #d0ecff",
    marginBottom: "25px",
    outline: "none",
    transition: "0.3s",
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
    gap: "20px",
  },

  card: {
    padding: "15px",
    borderRadius: "18px",
    background: "rgba(255,255,255,0.8)",
    backdropFilter: "blur(10px)",
    boxShadow: "0 5px 25px rgba(0,150,255,0.2)",
    textAlign: "center",
    transition: "0.3s",
  },

  image: {
    width: "100%",
    height: "180px",
    objectFit: "cover",
    borderRadius: "12px",
    marginBottom: "10px",
  },

  desc: {
    fontSize: "13px",
    color: "#555",
  },

  price: {
    color: "#0077b6",
  },

  button: {
    marginTop: "10px",
    padding: "10px",
    width: "100%",
    borderRadius: "10px",
    border: "none",
    background: "linear-gradient(135deg, #00c6ff, #0072ff)",
    color: "#fff",
    cursor: "pointer",
    transition: "0.3s",
  },

  cartBox: {
    marginTop: "40px",
    padding: "20px",
    borderRadius: "18px",
    background: "rgba(255,255,255,0.85)",
    boxShadow: "0 5px 25px rgba(0,150,255,0.2)",
  },

  cartItem: {
    display: "flex",
    justifyContent: "space-between",
    marginBottom: "10px",
  },

  removeBtn: {
    border: "none",
    background: "#ff4d4d",
    color: "#fff",
    borderRadius: "6px",
    padding: "5px 10px",
    cursor: "pointer",
  },

  total: {
    marginTop: "15px",
    color: "#0077b6",
  },

  checkout: {
    marginTop: "10px",
    padding: "12px",
    width: "100%",
    borderRadius: "10px",
    border: "none",
    background: "linear-gradient(135deg, #00c6ff, #0072ff)",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
  },
};

// animations + hover
const styleSheet = document.createElement("style");
styleSheet.innerHTML = `
.card:hover {
  transform: translateY(-5px) scale(1.02);
}
button:hover {
  transform: translateY(-2px) scale(1.03);
  box-shadow: 0 8px 20px rgba(0,140,255,0.3);
}
input:focus {
  border-color: #00b4ff;
  box-shadow: 0 0 6px rgba(0,180,255,0.4);
}
`;
document.head.appendChild(styleSheet);