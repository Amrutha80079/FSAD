package com.marketplace.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marketplace.model.User;
import com.marketplace.repository.UserRepository;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    // ✅ REGISTER
    public User register(User user) {
        return repo.save(user);
    }

    // ✅ LOGIN (FULL SAFE VERSION)
    public Optional<User> login(String username, String password) {

        // ❌ null check
        if (username == null || password == null) {
            return Optional.empty();
        }

        Optional<User> user = repo.findByUsername(username);

        // ❌ user not found
        if (user.isEmpty()) {
            return Optional.empty();
        }

        // ❌ stored password null
        if (user.get().getPassword() == null) {
            return Optional.empty();
        }

        // ❌ password mismatch
        if (!user.get().getPassword().equals(password)) {
            return Optional.empty();
        }

        // ✅ success
        return user;
    }
}