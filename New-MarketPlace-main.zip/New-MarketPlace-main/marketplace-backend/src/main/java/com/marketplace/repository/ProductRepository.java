package com.marketplace.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.marketplace.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
}