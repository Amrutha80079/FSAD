package com.marketplace.controller;

import org.springframework.web.bind.annotation.*;

import com.marketplace.model.User;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin("*")
public class AuthController {

    // ❌ Disable register (optional)
    @PostMapping("/register")
    public String register(@RequestBody User user) {
        return "Registration disabled";
    }

    // 🔥 HARD-CODED LOGIN
    @PostMapping("/login")
    public String login(@RequestBody User user) {

        if ("sohail".equals(user.getUsername()) &&
            "1234".equals(user.getPassword())) {

            return "Login successful";
        }

        return "Invalid credentials";
    }
}